package com.nedim.canrec

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var toggle: Button
    private lateinit var etNote: EditText
    private lateinit var cbSerial: CheckBox
    private val ui = Handler(Looper.getMainLooper())

    private val marks = listOf(
        "Kapi ACILDI", "Kapi KAPANDI", "Sol sinyal", "Sag sinyal", "Dortlu", "Far ACIK", "Far KAPALI",
        "Fren pedali", "Gaza tam bastim", "Direksiyon butonu: yol bilgisayari", "Klima/fan degisti",
        "Geri vites", "Cam acildi", "Rolanti (duruyorum)", "Hareket ettim"
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 16, 24, 16) }

        toggle = Button(this).apply { textSize = 22f; setOnClickListener { onToggle() } }
        root.addView(toggle, LinearLayout.LayoutParams(-1, 160))

        cbSerial = CheckBox(this).apply { text = "Seri portlari da dinle (Raise'in verisini bozarsa kapat)"; isChecked = true }
        root.addView(cbSerial)
        status = TextView(this).apply { textSize = 14f; setPadding(0, 12, 0, 12) }
        root.addView(status)

        root.addView(TextView(this).apply {
            text = "Olay isaretleri (kayit sirasinda bas, yolcu basabilir):"; textSize = 13f
        })
        var rowLayout: LinearLayout? = null
        marks.forEachIndexed { i, m ->
            if (i % 3 == 0) {
                rowLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                root.addView(rowLayout, LinearLayout.LayoutParams(-1, -2))
            }
            rowLayout!!.addView(Button(this).apply {
                text = m; isAllCaps = false; textSize = 12f
                setOnClickListener { sendMark(m) }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        val noteRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        etNote = EditText(this).apply { hint = "kendi notun"; setSingleLine() }
        noteRow.addView(etNote, LinearLayout.LayoutParams(0, -2, 1f))
        noteRow.addView(Button(this).apply {
            text = "Notu ekle"; isAllCaps = false
            setOnClickListener { val t = etNote.text.toString().trim(); if (t.isNotEmpty()) { sendMark("NOT: $t"); etNote.setText("") } }
        })
        root.addView(noteRow)

        root.addView(TextView(this).apply {
            textSize = 12f; setPadding(0, 16, 0, 0)
            text = "Onerilen senaryo:\n" +
                "1) Kaydi baslat, arac durur ve motor rolantide iken 2 dk: kapi ac/kapa, sinyaller, far, fren, klima, direksiyon butonu ile yol bilgisayari sayfalarini sirayla gez (her birinde isarete bas).\n" +
                "2) Sonra normal surus (1 saat). Ara sira 'Gaza tam bastim', 'Fren pedali' isaretle.\n" +
                "3) Bitince KAYDI BITIR. Dosya Download klasorune ve takili USB belle(ge)e de kopyalanir. Kayit sirasinda dosya surekli yazildigi icin kontak kapansa bile o ana kadarki veri kalir."
        })

        val sv = ScrollView(this).apply { addView(root) }
        setContentView(sv)

        if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        }
        tryRootGrant()
        tick()
    }

    private fun tryRootGrant() {
        if (has("android.permission.READ_LOGS") && has("android.permission.DUMP")) return
        Thread {
            try {
                val cmd = "pm grant com.nedim.canrec android.permission.READ_LOGS; pm grant com.nedim.canrec android.permission.DUMP"
                val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
                p.waitFor()
            } catch (e: Exception) {}
        }.start()
    }

    private fun has(p: String): Boolean =
        Build.VERSION.SDK_INT < 23 || checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun onToggle() {
        val i = Intent(this, RecorderService::class.java)
        if (RecorderService.running) {
            i.action = RecorderService.ACT_STOP
            startService(i)
        } else {
            i.action = RecorderService.ACT_START
            i.putExtra(RecorderService.EXTRA_SERIAL, cbSerial.isChecked)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        }
    }

    private fun sendMark(label: String) {
        if (!RecorderService.running) { Toast.makeText(this, "Once kaydi baslat", Toast.LENGTH_SHORT).show(); return }
        val i = Intent(this, RecorderService::class.java)
        i.action = RecorderService.ACT_MARK
        i.putExtra(RecorderService.EXTRA_LABEL, label)
        startService(i)
        Toast.makeText(this, "Isaretlendi: $label", Toast.LENGTH_SHORT).show()
    }

    private fun tick() {
        val r = RecorderService.running
        toggle.text = if (r) "■  KAYDI BITIR" else "●  KAYDI BASLAT"
        toggle.setBackgroundColor(if (r) Color.parseColor("#C62828") else Color.parseColor("#2E7D32"))
        toggle.setTextColor(Color.WHITE)
        val sb = StringBuilder()
        val logOk = has("android.permission.READ_LOGS")
        val dumpOk = has("android.permission.DUMP")
        sb.append("READ_LOGS: ${if (logOk) "VAR" else "YOK"}   DUMP: ${if (dumpOk) "VAR" else "YOK"}   Konum: ${if (has(Manifest.permission.ACCESS_FINE_LOCATION)) "VAR" else "YOK"}\n")
        if (!logOk || !dumpOk) sb.append("! PC'den bir kez: adb shell pm grant com.nedim.canrec android.permission.READ_LOGS  (ve ...DUMP)\n")
        if (r) {
            val sec = (System.currentTimeMillis() - RecorderService.startMs) / 1000
            sb.append("Sure: %d:%02d:%02d   Satir: %d   Boyut: %.1f MB\n".format(sec / 3600, sec % 3600 / 60, sec % 60, RecorderService.rows, RecorderService.bytes / 1048576.0))
            sb.append("Logcat etiket sayisi: ${RecorderService.tagCount}   Broadcast: ${RecorderService.bcastCount}   GPS: ${RecorderService.gpsCount}\n")
            sb.append("Seri: ${RecorderService.serialPorts} port acik, ${RecorderService.serialBytes} bayt okundu\n")
            if (sec > 10 && RecorderService.tagCount <= 1) sb.append("! Logcat bos geliyor (READ_LOGS izni verilmemis olabilir)\n")
            if (sec > 20 && RecorderService.gpsCount == 0) sb.append("! GPS verisi yok (ac/izin ver; bu sadece hiz referansi)\n")
        }
        if (RecorderService.note.isNotEmpty()) sb.append("Not: ${RecorderService.note}\n")
        if (RecorderService.path.isNotEmpty()) {
            sb.append("Dosya: ${RecorderService.path}\n")
            if (RecorderService.downloadCopy.isNotEmpty()) sb.append("Kopya: ${RecorderService.downloadCopy}\n")
        }
        status.text = sb.toString()
        ui.postDelayed({ tick() }, 1000)
    }
}
