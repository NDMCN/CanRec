package com.nedim.canrec

import android.app.ActivityManager
import android.app.admin.DevicePolicyManager
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.os.Build
import android.provider.Settings
import java.io.File
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Date
import java.util.Locale

/** Sistem kaynak izleme, baglanti izleme ve guvenlik taramasi. Satirlari row() ile CSV'ye yazar. */
class Monitors(
    private val ctx: Context,
    private val row: (String, String, String) -> Unit,
    private val running: () -> Boolean
) {
    private val pkgCache = HashMap<Int, String>()
    @Volatile private var dumpOk = true

    private fun pkgOf(uid: Int): String = synchronized(pkgCache) {
        pkgCache.getOrPut(uid) {
            try { ctx.packageManager.getPackagesForUid(uid)?.joinToString("|") ?: "uid$uid" } catch (e: Exception) { "uid$uid" }
        }
    }

    private fun runCmd(vararg c: String): List<String> = try {
        val p = Runtime.getRuntime().exec(c)
        val l = p.inputStream.bufferedReader().readLines()
        p.waitFor(); l
    } catch (e: Exception) { listOf("HATA: $e") }

    // =============== 1) CPU / RAM / sicaklik, her 10 sn ===============
    fun sysLoop() {
        var prev: LongArray? = null
        var tick = 0
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        while (running()) {
            try {
                val sb = StringBuilder()
                val mi = ActivityManager.MemoryInfo()
                am.getMemoryInfo(mi)
                sb.append("ram_bos_MB=${mi.availMem / 1048576} ram_toplam_MB=${mi.totalMem / 1048576} dusuk_bellek=${mi.lowMemory}")
                memExtra()?.let { sb.append(' ').append(it) }
                val cur = readCpuStat()
                val p = prev
                if (cur != null && p != null) {
                    val dt = cur[0] - p[0]
                    val di = cur[1] - p[1]
                    if (dt > 0) sb.append(" cpu_yuzde=${100 * (dt - di) / dt}")
                }
                if (cur != null) prev = cur
                loadAvg()?.let { sb.append(" yuk=").append(it) }
                temps()?.let { sb.append(' ').append(it) }
                freqs()?.let { sb.append(' ').append(it) }
                row("SYS", "kaynak", sb.toString())
                if (dumpOk && tick % 6 == 0) dumpCpu()
                if (dumpOk && tick % 30 == 3) dumpMem()
            } catch (e: Throwable) { row("INFO", "sys-hata", e.toString()) }
            tick++
            try { Thread.sleep(10_000) } catch (e: InterruptedException) { break }
        }
    }

    private fun readCpuStat(): LongArray? = try {
        val l = File("/proc/stat").readLines().firstOrNull { it.startsWith("cpu ") }
        if (l == null) null else {
            val f = l.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
            if (f.size < 5) null else longArrayOf(f.take(8).sum(), f[3] + f[4])
        }
    } catch (e: Exception) { null }

    private fun memExtra(): String? = try {
        val m = HashMap<String, Long>()
        File("/proc/meminfo").readLines().forEach { l ->
            val k = l.substringBefore(':')
            val v = l.substringAfter(':').trim().substringBefore(' ').toLongOrNull()
            if (v != null) m[k] = v
        }
        val st = m["SwapTotal"] ?: 0L
        val sf = m["SwapFree"] ?: 0L
        "swap_kullanilan_MB=${(st - sf) / 1024} cached_MB=${(m["Cached"] ?: 0L) / 1024}"
    } catch (e: Exception) { null }

    private fun loadAvg(): String? = try {
        File("/proc/loadavg").readText().trim().split(" ").take(3).joinToString("/")
    } catch (e: Exception) { null }

    private fun temps(): String? = try {
        val zones = File("/sys/class/thermal").listFiles { f -> f.name.startsWith("thermal_zone") }
            ?.sortedBy { it.name }?.take(8)
        val parts = zones?.mapNotNull { z ->
            try {
                val t = File(z, "temp").readText().trim().toLong()
                val ty = try { File(z, "type").readText().trim().replace(' ', '_') } catch (e: Exception) { z.name }
                "t_$ty=${if (t > 1000) t / 1000 else t}"
            } catch (e: Exception) { null }
        }
        if (parts.isNullOrEmpty()) null else parts.joinToString(" ")
    } catch (e: Exception) { null }

    private fun freqs(): String? = try {
        val cpus = File("/sys/devices/system/cpu").listFiles { f -> Regex("cpu\\d+").matches(f.name) }?.sortedBy { it.name }
        val parts = cpus?.mapNotNull { c ->
            try { (File(c, "cpufreq/scaling_cur_freq").readText().trim().toLong() / 1000).toString() } catch (e: Exception) { null }
        }
        if (parts.isNullOrEmpty()) null else "cpu_mhz=" + parts.joinToString(",")
    } catch (e: Exception) { null }

    private fun dumpCpu() {
        val lines = runCmd("dumpsys", "cpuinfo")
        if (lines.any { it.contains("Permission Denial") || it.contains("HATA") }) {
            dumpOk = false
            row("INFO", "dumpsys", "DUMP izni yok: surec bazli CPU/RAM alinamadi (adb shell pm grant com.nedim.canrec android.permission.DUMP)")
            return
        }
        lines.filter { it.isNotBlank() }.take(25).forEach { row("DUMP-CPU", "", it.trim()) }
    }

    private fun dumpMem() {
        val lines = runCmd("dumpsys", "meminfo")
        if (lines.any { it.contains("Permission Denial") || it.contains("HATA") }) { dumpOk = false; return }
        lines.takeWhile { !it.contains("by OOM adj") }.filter { it.isNotBlank() }.take(45).forEach { row("DUMP-MEM", "", it.trim()) }
    }

    // =============== 2) Ag baglantilari (/proc/net) ===============
    fun netLoop() {
        val seen = HashSet<String>()
        var warned = false
        while (running()) {
            var readable = false
            for (f in listOf("tcp", "tcp6", "udp", "udp6")) {
                val lines = try { File("/proc/net/$f").readLines() } catch (e: Exception) { continue }
                readable = true
                val isTcp = f.startsWith("tcp")
                for (l in lines.drop(1)) {
                    try {
                        val p = l.trim().split(Regex("\\s+"))
                        if (p.size < 8) continue
                        val st = p[3]
                        val uid = p[7].toIntOrNull() ?: continue
                        val rem = parseAddr(p[2])
                        val loc = parseAddr(p[1])
                        val kind: String = when {
                            isTcp && st == "0A" -> "DINLIYOR"
                            isTcp && (st == "01" || st == "02") -> "BAGLANTI"
                            !isTcp && !rem.endsWith(":0") -> "UDP-BAGLI"
                            else -> continue
                        }
                        val shown = if (kind == "DINLIYOR") loc else rem
                        if (shown.startsWith("127.") || shown.startsWith("[::1]")) continue
                        if (seen.add("$kind|$uid|$shown")) row("NET", kind, "uid=$uid pkg=${pkgOf(uid)} adres=$shown")
                    } catch (e: Exception) { }
                }
            }
            if (!readable && !warned) {
                warned = true
                row("INFO", "net", "/proc/net okunamadi (Android kisitlamasi): baglanti listesi yok")
            }
            try { Thread.sleep(5_000) } catch (e: InterruptedException) { break }
        }
    }

    private fun leIp4(h: String): String = (3 downTo 0).joinToString(".") { h.substring(it * 2, it * 2 + 2).toInt(16).toString() }

    private fun parseAddr(s: String): String {
        val h = s.substringBefore(':')
        val port = s.substringAfter(':').toInt(16)
        return if (h.length == 8) "${leIp4(h)}:$port" else {
            val w = (0 until 4).map { h.substring(it * 8, it * 8 + 8) }
            if (w[0] == "00000000" && w[1] == "00000000" && w[2].equals("0000FFFF", true)) "${leIp4(w[3])}:$port"
            else "[" + w.joinToString(":") { x -> val r = x.chunked(2).reversed().joinToString(""); r.substring(0, 4) + ":" + r.substring(4) } + "]:$port"
        }
    }

    // =============== 3) Guvenlik taramasi (baslangicta bir kez) ===============
    fun securityScan() {
        try {
            val cr = ctx.contentResolver
            fun g(ns: String, k: String): String? = try {
                if (ns == "global") Settings.Global.getString(cr, k) else Settings.Secure.getString(cr, k)
            } catch (e: Exception) { null }
            listOf("adb_enabled", "development_settings_enabled", "http_proxy", "global_http_proxy_host", "private_dns_mode", "private_dns_specifier")
                .forEach { row("SEC", "ayar:$it", g("global", it) ?: "(yok)") }
            listOf("enabled_accessibility_services", "accessibility_enabled", "enabled_notification_listeners", "default_input_method", "enabled_input_methods", "install_non_market_apps")
                .forEach { row("SEC", "ayar:$it", g("secure", it) ?: "(yok)") }

            val keys = setOf(
                "ro.debuggable", "ro.secure", "ro.build.tags", "ro.build.type", "ro.build.fingerprint",
                "ro.build.version.security_patch", "service.adb.tcp.port", "persist.adb.tcp.port", "init.svc.adbd",
                "persist.sys.usb.config", "sys.usb.config", "ro.boot.verifiedbootstate", "ro.boot.flash.locked"
            )
            val rx = Regex("\\[(.+?)\\]: \\[(.*)\\]")
            runCmd("getprop").forEach { l ->
                val m = rx.find(l)
                if (m != null && m.groupValues[1] in keys) row("SEC", "prop", "${m.groupValues[1]}=${m.groupValues[2]}")
            }
            row("SEC", "selinux", runCmd("getenforce").firstOrNull() ?: "?")
            val su = listOf("/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su", "/vendor/bin/su", "/system/app/Superuser.apk", "/system/app/SuperSU")
                .filter { File(it).exists() }
            row("SEC", "root", if (su.isEmpty()) "su dosyasi bulunamadi" else "su VAR: ${su.joinToString(",")}")

            try {
                val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                row("SEC", "cihaz-yoneticisi", dpm.activeAdmins?.joinToString(",") { it.flattenToShortString() } ?: "yok")
            } catch (e: Exception) { row("SEC", "cihaz-yoneticisi", "okunamadi: $e") }

            try {
                val ks = java.security.KeyStore.getInstance("AndroidCAStore")
                ks.load(null, null)
                val all = Collections.list(ks.aliases())
                val user = all.filter { it.startsWith("user:") }
                row("SEC", "sertifika", "sistem+kullanici CA=${all.size}, kullanicinin eklediği=${user.size} ${user.take(10).joinToString(",")}")
            } catch (e: Exception) { row("SEC", "sertifika", "okunamadi: $e") }

            try {
                @Suppress("DEPRECATION")
                val svc = (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getRunningServices(200)
                val names = svc.map { it.process }.distinct().take(80)
                row("SEC", "calisan-servisler", "${names.size} surec: ${names.joinToString(",")}")
            } catch (e: Exception) { }

            packageAudit()
        } catch (e: Throwable) { row("INFO", "guvenlik-hata", e.toString()) }
    }

    private fun packageAudit() {
        val pm = ctx.packageManager
        val sens = setOf(
            "RECORD_AUDIO", "CAMERA", "READ_SMS", "SEND_SMS", "RECEIVE_SMS", "READ_CONTACTS", "READ_CALL_LOG",
            "ACCESS_FINE_LOCATION", "ACCESS_BACKGROUND_LOCATION", "SYSTEM_ALERT_WINDOW", "REQUEST_INSTALL_PACKAGES",
            "INSTALL_PACKAGES", "BIND_ACCESSIBILITY_SERVICE", "BIND_DEVICE_ADMIN", "READ_PHONE_STATE", "WRITE_SETTINGS",
            "PACKAGE_USAGE_STATS", "GET_ACCOUNTS", "READ_LOGS", "DUMP", "WRITE_SECURE_SETTINGS", "RECEIVE_BOOT_COMPLETED"
        )
        val minerRx = Regex("miner|mining|xmrig|monero|cryptonight|nicehash|coinhive", RegexOption.IGNORE_CASE)
        val df = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val all = pm.getInstalledPackages(0)
        var user = 0
        var sys = 0
        for (pi in all) {
            try {
                val ai = pi.applicationInfo ?: continue
                val isSys = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                val updSys = (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
                val dbg = (ai.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
                val full = try { pm.getPackageInfo(pi.packageName, PackageManager.GET_PERMISSIONS) } catch (e: Exception) { pi }
                val perms = full.requestedPermissions?.map { it.substringAfterLast('.') } ?: emptyList()
                val hasNet = "INTERNET" in perms
                val risky = perms.filter { it in sens }.distinct()
                val label = try { pm.getApplicationLabel(ai).toString() } catch (e: Exception) { "" }
                val miner = minerRx.containsMatchIn(pi.packageName) || minerRx.containsMatchIn(label)
                if (isSys) sys++ else user++
                if (!isSys || updSys || miner || dbg || (hasNet && risky.size >= 3)) {
                    @Suppress("DEPRECATION")
                    val inst = try { pm.getInstallerPackageName(pi.packageName) } catch (e: Exception) { null }
                    row(
                        "SEC", "paket",
                        "${pi.packageName} | $label | ${if (isSys) "SISTEM" else "KULLANICI"}${if (updSys) "(guncellenmis)" else ""}" +
                            " | yukleyen=${inst ?: "yok"} | ilk=${df.format(Date(pi.firstInstallTime))} | internet=$hasNet" +
                            " | riskli=${risky.joinToString(",")}${if (miner) " | !!MINER-ADI" else ""}${if (dbg) " | DEBUGGABLE" else ""}"
                    )
                }
            } catch (e: Exception) { }
        }
        row("SEC", "ozet", "toplam=${all.size} sistem=$sys kullanici=$user")
    }

    // =============== 4) Uygulama bazli ag kullanimi (kayit sonunda) ===============
    fun netStats(startMs: Long) {
        if (Build.VERSION.SDK_INT < 23) return
        try {
            val nsm = ctx.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
            val now = System.currentTimeMillis()
            listOf("kayit" to startMs, "son24saat" to now - 24L * 3600 * 1000).forEach { (name, from) ->
                val per = HashMap<Int, LongArray>()
                for (type in listOf(ConnectivityManager.TYPE_WIFI, ConnectivityManager.TYPE_MOBILE)) {
                    try {
                        val st = nsm.querySummary(type, null, from, now)
                        val b = NetworkStats.Bucket()
                        while (st.hasNextBucket()) {
                            st.getNextBucket(b)
                            val a = per.getOrPut(b.uid) { LongArray(2) }
                            a[0] += b.rxBytes
                            a[1] += b.txBytes
                        }
                        st.close()
                    } catch (e: Exception) { row("SEC", "netstats-$name", "tip=$type: $e") }
                }
                per.entries.sortedByDescending { it.value[0] + it.value[1] }.take(25).forEach { (uid, a) ->
                    row("SEC", "netstats-$name", "uid=$uid pkg=${pkgOf(uid)} indirilen_KB=${a[0] / 1024} gonderilen_KB=${a[1] / 1024}")
                }
            }
        } catch (e: Throwable) {
            row("SEC", "netstats", "okunamadi (Kullanim erisimi izni gerekir): $e")
        }
    }
}
