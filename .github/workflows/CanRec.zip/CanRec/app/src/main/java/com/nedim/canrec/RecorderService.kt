package com.nedim.canrec

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import java.io.BufferedWriter
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

class RecorderService : Service() {

    companion object {
        const val ACT_START = "canrec.start"
        const val ACT_STOP = "canrec.stop"
        const val ACT_MARK = "canrec.mark"
        const val EXTRA_LABEL = "label"
        const val EXTRA_SERIAL = "serial"
        @Volatile var running = false
        @Volatile var startMs = 0L
        @Volatile var rows = 0L
        @Volatile var bytes = 0L
        @Volatile var path = ""
        @Volatile var tagCount = 0
        @Volatile var bcastCount = 0
        @Volatile var gpsCount = 0
        @Volatile var note = ""
        @Volatile var downloadCopy = ""
        @Volatile var serialBytes = 0L
        @Volatile var serialPorts = 0
        @Volatile var diskFull = false
        private val LOGRX = Regex("""^(\d\d-\d\d \d\d:\d\d:\d\d\.\d{3}) (\w)/(.*?)\(\s*(\d+)\): (.*)$""")
        private val ACTION_RX = Regex("""Action: "([^"]+)"""")
        private val INTEREST_RX = Regex(
            "can|mcu|syu|raise|rzc|hiworld|vehicle|carinfo|canbus|fuel|oil|speed|rpm|door|gear|brake|trip|odometer|tpms|radar|steer|swc|reverse|aircon|climate",
            RegexOption.IGNORE_CASE
        )
    }

    private var writer: BufferedWriter? = null
    private val lock = Any()
    private val clockFmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private var logProc: Process? = null
    private var logThread: Thread? = null
    private var wake: PowerManager.WakeLock? = null
    private var receiver: BroadcastReceiver? = null
    private var locListener: LocationListener? = null
    private val ui = Handler(Looper.getMainLooper())
    private val tagSeen = ConcurrentHashMap<String, Boolean>()
    private val serialStreams = CopyOnWriteArrayList<FileInputStream>()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACT_START -> {
                goForeground()
                if (!running) startRecording(intent?.getBooleanExtra(EXTRA_SERIAL, true) ?: true)
            }
            ACT_STOP -> Thread { stopRecording(); stopSelf() }.start()
            ACT_MARK -> row("MARK", "", intent?.getStringExtra(EXTRA_LABEL) ?: "isaret")
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stopRecording()
        super.onDestroy()
    }

    private fun goForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val b: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("rec", "Kayit", NotificationManager.IMPORTANCE_LOW))
            b = Notification.Builder(this, "rec")
        } else {
            b = Notification.Builder(this)
        }
        val n = b.setContentTitle("CAN kaydi suruyor").setSmallIcon(android.R.drawable.ic_menu_save).build()
        startForeground(1, n)
    }

    // ---------------- CSV yazma ----------------
    private fun q(s: String): String {
        var t = s.replace("\r", " ").replace("\n", " ")
        if (t.length > 600) t = t.substring(0, 600)
        return if (t.contains(';') || t.contains('"')) "\"" + t.replace("\"", "\"\"") + "\"" else t
    }

    private fun row(source: String, tag: String, data: String) {
        synchronized(lock) {
            val w = writer ?: return
            if (diskFull && source != "MARK") return
            val now = System.currentTimeMillis()
            val line = "${now - startMs};${clockFmt.format(Date(now))};$source;${q(tag)};${q(data)}\n"
            try {
                w.write(line)
                bytes += line.length
                rows++
            } catch (e: Exception) { note = "Yazma hatasi: $e" }
        }
    }

    // ---------------- Baslat / Bitir ----------------
    private fun startRecording(serialOn: Boolean) {
        running = true
        diskFull = false; serialBytes = 0; serialPorts = 0
        serialStreams.clear()
        startMs = System.currentTimeMillis()
        rows = 0; bytes = 0; tagCount = 0; bcastCount = 0; gpsCount = 0; note = ""; downloadCopy = ""
        tagSeen.clear()
        val dir = getExternalFilesDir(null) ?: filesDir
        val f = File(dir, "canrec_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".csv")
        path = f.absolutePath
        synchronized(lock) {
            writer = BufferedWriter(OutputStreamWriter(FileOutputStream(f), Charsets.UTF_8), 1 shl 16)
            writer!!.write("\uFEFF")
            writer!!.write("t_ms;saat;kaynak;etiket;veri\n")
        }
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "canrec:rec").also { it.acquire() }
        row("MARK", "", "KAYIT BASLADI")
        writeInfo()
        startLogcat()
        startBroadcasts()
        startGps()
        if (serialOn) startSerial() else row("INFO", "serial", "seri port dinleme kapali")
        flushLoop()
    }

    private fun flushLoop() {
        ui.postDelayed({
            if (running) {
                synchronized(lock) { try { writer?.flush() } catch (e: Exception) {} }
                try {
                    if (File(path).usableSpace < 150L * 1024 * 1024) { diskFull = true; note = "Disk dolu (<150 MB), yazma durdu" }
                } catch (e: Exception) {}
                flushLoop()
            }
        }, 2000)
    }

    private fun stopRecording() {
        if (!running) return
        running = false
        row("MARK", "", "KAYIT BITTI")
        try { logProc?.destroy() } catch (e: Exception) {}
        serialStreams.forEach { try { it.close() } catch (e: Exception) {} }
        try { logThread?.join(1500) } catch (e: Exception) {}
        try { receiver?.let { unregisterReceiver(it) } } catch (e: Exception) {}
        receiver = null
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            locListener?.let { lm.removeUpdates(it) }
        } catch (e: Exception) {}
        locListener = null
        ui.removeCallbacksAndMessages(null)
        synchronized(lock) {
            try { writer?.flush(); writer?.close() } catch (e: Exception) {}
            writer = null
        }
        val targets = LinkedHashSet<File>()
        try { targets.add(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)) } catch (e: Exception) {}
        try { getExternalFilesDirs(null)?.forEach { if (it != null) targets.add(it) } } catch (e: Exception) {}
        listOf("/storage", "/mnt/media_rw", "/mnt/usb_storage", "/mnt").forEach { base ->
            File(base).listFiles()?.forEach { d ->
                if (d.isDirectory && d.name != "emulated" && d.name != "self" && d.name != "sdcard0" && d.canWrite()) targets.add(d)
            }
        }
        val src = File(path)
        val ok = ArrayList<String>()
        targets.forEach { d ->
            try {
                d.mkdirs()
                val dst = File(d, src.name)
                if (dst.absolutePath != src.absolutePath) {
                    src.copyTo(dst, true)
                    ok.add(dst.absolutePath)
                }
            } catch (e: Exception) {}
        }
        downloadCopy = if (ok.isEmpty()) "(kopya yazilamadi)" else ok.joinToString("\n       ")
        try { wake?.release() } catch (e: Exception) {}
        stopForeground(true)
    }

    // ---------------- Kaynak 0: sistem bilgisi ----------------
    private fun writeInfo() {
        Thread {
            try {
                row("INFO", "build", "android=${Build.VERSION.RELEASE} sdk=${Build.VERSION.SDK_INT} model=${Build.MODEL} hw=${Build.HARDWARE} board=${Build.BOARD}")
                val rx = Regex("can|mcu|raise|rzc|uart|serial|syu|hiworld", RegexOption.IGNORE_CASE)
                runCmd("getprop").filter { rx.containsMatchIn(it) }.take(60).forEach { row("INFO", "getprop", it) }
                File("/dev").listFiles()?.filter { Regex("^tty(S|MT|HS|USB|ACM|AMA|XR|GS).*").matches(it.name) || rx.containsMatchIn(it.name) }
                    ?.sortedBy { it.name }?.forEach { row("INFO", "dev", "${it.absolutePath} read=${it.canRead()} write=${it.canWrite()}") }
                val pm = packageManager
                pm.getInstalledPackages(0).filter { rx.containsMatchIn(it.packageName) }.forEach {
                    row("INFO", "paket", "${it.packageName} v${it.versionName}")
                }
            } catch (e: Throwable) { row("INFO", "hata", e.toString()) }
        }.start()
    }

    private fun runCmd(vararg c: String): List<String> = try {
        val p = Runtime.getRuntime().exec(c)
        val l = p.inputStream.bufferedReader().readLines()
        p.waitFor(); l
    } catch (e: Exception) { listOf("HATA: $e") }

    // ---------------- Kaynak 1: logcat ----------------
    private fun startLogcat() {
        val t = Thread {
            try {
                val p = Runtime.getRuntime().exec(arrayOf("logcat", "-v", "time"))
                logProc = p
                val rd = p.inputStream.bufferedReader()
                val yr = Calendar.getInstance().get(Calendar.YEAR)
                val parser = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)
                val last = HashMap<String, String>()
                val rep = HashMap<String, Int>()
                val myPid = android.os.Process.myPid()
                while (running) {
                    val line = rd.readLine() ?: break
                    val m = LOGRX.matchEntire(line) ?: continue
                    val (ts, lvl, tag0, pid, msg) = m.destructured
                    if (pid.toIntOrNull() == myPid) continue
                    val tms = try { parser.parse("$yr-$ts")?.time ?: 0L } catch (e: Exception) { 0L }
                    if (tms < startMs - 500) continue
                    val tag = tag0.trim()
                    if (tagSeen.put(tag, true) == null) tagCount = tagSeen.size
                    if (last[tag] == msg) { rep[tag] = (rep[tag] ?: 0) + 1; continue }
                    val r = rep.remove(tag)
                    if (r != null && r > 0) row("LOGCAT", tag, "(ayni satir $r kez daha tekrarlandi)")
                    row("LOGCAT", "$lvl/$tag", msg)
                    last[tag] = msg
                }
                rep.forEach { (tag, r) -> if (r > 0) row("LOGCAT", tag, "(ayni satir $r kez daha tekrarlandi)") }
            } catch (e: Throwable) { row("INFO", "logcat-hata", e.toString()) }
        }
        logThread = t
        t.start()
    }

    // ---------------- Kaynak 2: broadcast'ler ----------------
    private fun startBroadcasts() {
        Thread {
            try {
                val actions = LinkedHashSet<String>()
                runCmd("dumpsys", "package").forEach { l ->
                    ACTION_RX.find(l)?.let { m ->
                        val a = m.groupValues[1]
                        if (!a.startsWith("android.") && !a.startsWith("com.google.") && !a.startsWith("com.android.") && INTEREST_RX.containsMatchIn(a))
                            actions.add(a)
                    }
                }
                if (actions.isEmpty()) { row("INFO", "bcast", "ilgili action bulunamadi (DUMP izni yok olabilir)"); return@Thread }
                val f = IntentFilter()
                actions.forEach { f.addAction(it) }
                val r = object : BroadcastReceiver() {
                    override fun onReceive(c: Context, i: Intent) {
                        val ex = i.extras
                        val s = if (ex == null) "" else ex.keySet().joinToString(", ") { k -> "$k=${fmt(ex.get(k))}" }
                        bcastCount++
                        row("BCAST", i.action ?: "?", s)
                    }
                }
                registerReceiver(r, f)
                receiver = r
                row("INFO", "bcast", "dinlenen action (${actions.size}): ${actions.joinToString(",")}")
            } catch (e: Throwable) { row("INFO", "bcast-hata", e.toString()) }
        }.start()
    }

    private fun fmt(v: Any?): String = when (v) {
        null -> "null"
        is ByteArray -> v.joinToString("") { "%02X".format(it) }
        is IntArray -> v.joinToString(",", "[", "]")
        is FloatArray -> v.joinToString(",", "[", "]")
        is LongArray -> v.joinToString(",", "[", "]")
        is DoubleArray -> v.joinToString(",", "[", "]")
        is Array<*> -> v.joinToString(",", "[", "]")
        else -> v.toString()
    }

    // ---------------- Kaynak 4: seri port (ham bayt) ----------------
    private fun startSerial() {
        val rx = Regex("^tty(S|MT|HS|USB|ACM|AMA|XR|GS|WCH|CH).*")
        val all = File("/dev").listFiles()?.filter { rx.matches(it.name) }?.sortedBy { it.name } ?: emptyList()
        val ports = all.filter { it.canRead() }
        row("INFO", "serial", "toplam ${all.size} port, okunabilir ${ports.size}: ${ports.joinToString(",") { it.name }}")
        ports.forEach { port ->
            val t = Thread {
                try {
                    val ins = FileInputStream(port)
                    serialStreams.add(ins)
                    serialPorts++
                    row("INFO", "serial", "${port.name} acildi")
                    val buf = ByteArray(512)
                    var lastHex = ""
                    var rep = 0
                    while (running) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        if (n == 0) continue
                        serialBytes += n
                        val hex = buf.copyOf(n).joinToString(" ") { "%02X".format(it) }
                        if (hex == lastHex) { rep++; continue }
                        if (rep > 0) row("SERIAL", port.name, "(ayni paket $rep kez daha)")
                        rep = 0
                        lastHex = hex
                        row("SERIAL", port.name, "n=$n $hex")
                    }
                    if (rep > 0) row("SERIAL", port.name, "(ayni paket $rep kez daha)")
                } catch (e: Throwable) {
                    if (running) row("INFO", "serial", "${port.name} hata: $e")
                }
            }
            t.isDaemon = true
            t.start()
        }
    }

    // ---------------- Kaynak 3: GPS hizi (referans) ----------------
    private fun startGps() {
        try {
            if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                row("INFO", "gps", "konum izni yok"); return
            }
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val l = object : LocationListener {
                override fun onLocationChanged(loc: Location) {
                    gpsCount++
                    val sp = if (loc.hasSpeed()) String.format(Locale.US, "%.1f", loc.speed * 3.6f) else "yok"
                    row("GPS", "", "hiz_kmh=$sp dogruluk_m=${loc.accuracy.toInt()}")
                }
                @Deprecated("old")
                override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
                override fun onProviderEnabled(p: String) {}
                override fun onProviderDisabled(p: String) {}
            }
            locListener = l
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, l, Looper.getMainLooper())
        } catch (e: Throwable) { row("INFO", "gps-hata", e.toString()) }
    }
}
