package com.nedim.canrec

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.net.Uri
import android.os.IBinder
import android.provider.Settings
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.ZipFile

/**
 * Izin gerektirmeyen "derin" izleme:
 *  1) tum sistem ozellikleri (getprop) degisimleri
 *  2) Settings veritabani (system/secure/global) degisimleri
 *  3) com.hcn.* uygulamalarinin APK'sindaki metinleri tarama + bulunan broadcast'leri dinleme
 *  4) com.hcn.* ContentProvider ve servislerini yoklama
 */
class DeepMonitor(
    private val ctx: Context,
    private val row: (String, String, String) -> Unit,
    private val running: () -> Boolean,
    private val intervalMs: Long = 500L
) {
    private var receiver: BroadcastReceiver? = null
    private val watched = ArrayList<String>()

    private fun fmt(v: Any?): String = when (v) {
        null -> "null"
        is ByteArray -> v.joinToString("") { "%02X".format(it) }
        is IntArray -> v.joinToString(",", "[", "]")
        is FloatArray -> v.joinToString(",", "[", "]")
        is LongArray -> v.joinToString(",", "[", "]")
        is DoubleArray -> v.joinToString(",", "[", "]")
        is Array<*> -> v.joinToString(",", "[", "]")
        else -> v.toString()
    }

    // ================= 1) Sistem ozellikleri =================
    fun propLoop() {
        val cur = HashMap<String, String>()
        val cnt = HashMap<String, Int>()
        val rx = Regex("^\\[(.*?)\\]: \\[(.*)\\]$")
        var first = true
        while (running()) {
            try {
                val p = Runtime.getRuntime().exec("getprop")
                val lines = p.inputStream.bufferedReader().readLines()
                p.waitFor()
                val now = HashMap<String, String>()
                for (l in lines) {
                    val m = rx.find(l) ?: continue
                    now[m.groupValues[1]] = m.groupValues[2]
                }
                if (first) {
                    first = false
                    now.toSortedMap().forEach { (k, v) -> row("PROP0", k, v) }
                } else {
                    for ((k, v) in now) {
                        val o = cur[k]
                        if (o != v) {
                            val c = (cnt[k] ?: 0) + 1
                            cnt[k] = c
                            RecorderService.propChanges++
                            row("PROP", k, if (o == null) "(yeni) $v" else "$o -> $v")
                        }
                    }
                    for (k in cur.keys) if (!now.containsKey(k)) row("PROP", k, "(silindi)")
                }
                cur.clear()
                cur.putAll(now)
            } catch (e: Exception) { row("INFO", "prop-hata", e.toString()) }
            try { Thread.sleep(intervalMs) } catch (e: InterruptedException) { break }
        }
    }

    // ================= 2) Settings veritabani =================
    fun settingsLoop() {
        val uris = listOf("system" to Settings.System.CONTENT_URI, "secure" to Settings.Secure.CONTENT_URI, "global" to Settings.Global.CONTENT_URI)
        val cur = HashMap<String, String>()
        val cnt = HashMap<String, Int>()
        var first = true
        while (running()) {
            try {
                val now = HashMap<String, String>()
                for ((ns, uri) in uris) {
                    val c = (try { ctx.contentResolver.query(uri, arrayOf("name", "value"), null, null, null) } catch (e: Exception) { null }) ?: continue
                    c.use { while (it.moveToNext()) now["$ns/${it.getString(0)}"] = it.getString(1) ?: "" }
                }
                if (first) {
                    first = false
                    now.toSortedMap().forEach { (k, v) -> row("SETT0", k, v) }
                } else {
                    for ((k, v) in now) {
                        val o = cur[k]
                        if (o != v) {
                            val c = (cnt[k] ?: 0) + 1
                            cnt[k] = c
                            RecorderService.settChanges++
                            row("SETT", k, if (o == null) "(yeni) $v" else "$o -> $v")
                        }
                    }
                }
                cur.clear()
                cur.putAll(now)
            } catch (e: Exception) { row("INFO", "ayar-hata", e.toString()) }
            try { Thread.sleep(intervalMs) } catch (e: InterruptedException) { break }
        }
    }

    // ================= 3) APK metin tarama + broadcast dinleme =================
    private fun dexStrings(b: ByteArray): List<String> {
        if (b.size < 0x70) return emptyList()
        val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
        val n = bb.getInt(0x38)
        val off = bb.getInt(0x3C)
        if (n <= 0 || n > 600_000 || off <= 0 || off + n * 4L > b.size) return emptyList()
        val out = ArrayList<String>(n)
        for (i in 0 until n) {
            var p = bb.getInt(off + i * 4)
            if (p <= 0 || p >= b.size) continue
            while (p < b.size && (b[p].toInt() and 0x80) != 0) p++
            p++
            var e = p
            while (e < b.size && b[e].toInt() != 0) e++
            if (p < e && e - p < 400) out.add(String(b, p, e - p, Charsets.UTF_8))
        }
        return out
    }

    private val skipRx = Regex("^(android|java|javax|kotlin|kotlinx|org|com\\.google|androidx|dalvik|sun|libcore|junit|okhttp3|retrofit2|com\\.android|com\\.squareup)[.$]")
    private val dotRx = Regex("^[A-Za-z_][A-Za-z0-9_$]*(\\.[A-Za-z0-9_$]+){2,}$")
    private val propRx = Regex("^(sys|persist|ro|debug|vendor|hcn|can|mcu|dev|net|init|service)\\.[A-Za-z0-9_.\\-]+$")
    private val kwRx = Regex("can|mcu|speed|rpm|fuel|oil|door|temp|brake|gear|radar|steer|swc|volume|window|light|trip|odo|consum|tpms|accel|throttle|engine|battery|vehicle|socket|serial|uart|tty", RegexOption.IGNORE_CASE)
    private val wordRx = Regex("^[A-Za-z][A-Za-z0-9_ ]{4,48}$")
    private val ipRx = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$")

    /** HCN paketlerinin APK'sindaki metinleri tarar, aksiyon adayi listesini dondurur. */
    private fun apkScan(pkgs: List<String>): List<String> {
        val pm = ctx.packageManager
        val actions = LinkedHashSet<String>()
        for (pkg in pkgs) {
            try {
                val ai = pm.getApplicationInfo(pkg, 0)
                val paths = ArrayList<String>()
                paths.add(ai.sourceDir)
                ai.splitSourceDirs?.let { paths.addAll(it) }
                val seen = HashSet<String>()
                var rows = 0
                val cap = if (pkg == "com.hcn.autocan") 3000 else 800
                var dexCount = 0
                for (path in paths) {
                    ZipFile(path).use { z ->
                        val en = z.entries()
                        while (en.hasMoreElements()) {
                            val e = en.nextElement()
                            if (!e.name.endsWith(".dex")) continue
                            dexCount++
                            val bytes = z.getInputStream(e).readBytes()
                            val strs = dexStrings(bytes)
                            for (s in strs) {
                                if (rows >= cap) break
                                if (s.length < 5 || s.length > 110 || !seen.add(s)) continue
                                if (s.startsWith("content://")) { row("APKSTR", "$pkg:uri", s); rows++; continue }
                                if (s.startsWith("/dev/") || s.startsWith("/sys/") || s.startsWith("/proc/") || s.startsWith("/data/") || s.startsWith("/mnt/")) {
                                    row("APKSTR", "$pkg:yol", s); rows++; continue
                                }
                                if (ipRx.matches(s)) { row("APKSTR", "$pkg:ip", s); rows++; continue }
                                if (propRx.matches(s)) { row("APKSTR", "$pkg:ozellik", s); rows++; continue }
                                if (dotRx.matches(s) && !skipRx.containsMatchIn(s)) {
                                    row("APKSTR", "$pkg:nokta", s); rows++
                                    if (s.startsWith("com.hcn") || kwRx.containsMatchIn(s) || s.contains("ACTION")) actions.add(s)
                                    continue
                                }
                                if (wordRx.matches(s) && kwRx.containsMatchIn(s) && (s.contains('_') || s.all { it.isUpperCase() || it == ' ' })) {
                                    row("APKSTR", "$pkg:kelime", s); rows++
                                }
                            }
                        }
                    }
                }
                RecorderService.apkStrings += rows
                row("INFO", "apktarama", "$pkg: dex=$dexCount satir=$rows")
            } catch (e: Throwable) { row("INFO", "apktarama-hata", "$pkg: $e") }
        }
        return actions.toList()
    }

    private fun registerActions(actions: List<String>) {
        if (actions.isEmpty()) { row("INFO", "bcast2", "dinlenecek action bulunamadi"); return }
        val list = actions.take(500)
        val f = IntentFilter()
        list.forEach { f.addAction(it) }
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val ex = i.extras
                val s = if (ex == null) "" else ex.keySet().joinToString(", ") { k -> "$k=${fmt(ex.get(k))}" }
                RecorderService.bcastCount++
                row("BCAST", i.action ?: "?", s)
            }
        }
        try {
            ctx.registerReceiver(r, f)
            receiver = r
            row("INFO", "bcast2", "dinlenen action sayisi=${list.size}")
        } catch (e: Exception) { row("INFO", "bcast2-hata", e.toString()) }
    }

    // ================= 4) Provider / servis yoklama =================
    private fun providerProbe(pkgs: List<String>) {
        val pm = ctx.packageManager
        for (pkg in pkgs) {
            try {
                val pi = pm.getPackageInfo(pkg, PackageManager.GET_PROVIDERS)
                pi.providers?.forEach { p ->
                    row("PROVIDER", pkg, "${p.authority} exported=${p.exported} read=${p.readPermission}")
                    if (p.exported && p.authority != null) {
                        p.authority.split(";").forEach { a ->
                            try {
                                val c = ctx.contentResolver.query(Uri.parse("content://$a"), null, null, null, null)
                                if (c == null) row("PROVIDER-DATA", a, "null dondu")
                                else c.use {
                                    row("PROVIDER-DATA", a, "kolonlar=${it.columnNames.joinToString(",")} satir=${it.count}")
                                    watched.add(a)
                                }
                            } catch (e: Exception) { row("PROVIDER-DATA", a, "erisilemedi: ${e.javaClass.simpleName}") }
                        }
                    }
                }
            } catch (e: Exception) { }
        }
    }

    private fun providerWatch() {
        val last = HashMap<String, String>()
        while (running() && watched.isNotEmpty()) {
            for (a in watched.toList()) {
                try {
                    val c = ctx.contentResolver.query(Uri.parse("content://$a"), null, null, null, null) ?: continue
                    val sb = StringBuilder()
                    c.use {
                        var n = 0
                        while (it.moveToNext() && n < 25) {
                            n++
                            for (i in 0 until it.columnCount) {
                                val v = try { it.getString(i) } catch (e: Exception) { "?" }
                                sb.append(it.getColumnName(i)).append('=').append(v).append(';')
                            }
                            sb.append(" | ")
                        }
                    }
                    val s = sb.toString()
                    if (last[a] != s) { last[a] = s; row("PROVIDER", a, s) }
                } catch (e: Exception) { }
            }
            try { Thread.sleep(intervalMs) } catch (e: InterruptedException) { break }
        }
    }

    private fun serviceProbe(pkgs: List<String>) {
        val pm = ctx.packageManager
        var n = 0
        for (pkg in pkgs) {
            try {
                val pi = pm.getPackageInfo(pkg, PackageManager.GET_SERVICES)
                pi.services?.forEach { s ->
                    if (s.exported && n < 20) {
                        n++
                        val cn = ComponentName(pkg, s.name)
                        val conn = object : ServiceConnection {
                            override fun onServiceConnected(name: ComponentName, b: IBinder) {
                                val d = try { b.interfaceDescriptor } catch (e: Exception) { "?" }
                                row("SERVICE", name.flattenToShortString(), "baglandi descriptor=$d")
                                try { ctx.unbindService(this) } catch (e: Exception) { }
                            }
                            override fun onServiceDisconnected(name: ComponentName) {}
                        }
                        val ok = try { ctx.bindService(Intent().setComponent(cn), conn, Context.BIND_AUTO_CREATE) } catch (e: Exception) { false }
                        row("SERVICE", cn.flattenToShortString(), "bind_istegi=$ok")
                    }
                }
            } catch (e: Exception) { }
        }
    }

    /** Hepsini sirayla yapar; sonunda provider degisimlerini izlemeye devam eder. */
    fun discoverAndListen() {
        try {
            val pm = ctx.packageManager
            val all = pm.getInstalledPackages(0).map { it.packageName }
                .filter { it.startsWith("com.hcn.") && !it.contains(".theme.") && !it.contains(".skin") }
            val ordered = all.sortedBy { if (it == "com.hcn.autocan") 0 else 1 }
            row("INFO", "hcn-paketler", ordered.joinToString(","))
            registerActions(apkScan(ordered))
            providerProbe(ordered)
            serviceProbe(ordered)
            providerWatch()
        } catch (e: Throwable) { row("INFO", "derin-hata", e.toString()) }
    }

    fun stop() {
        try { receiver?.let { ctx.unregisterReceiver(it) } } catch (e: Exception) { }
        receiver = null
    }
}
