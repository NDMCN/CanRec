package com.nedim.canrec

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var toggle: Button
    private lateinit var lastMark: TextView
    private lateinit var etNote: EditText
    private lateinit var cbSerial: CheckBox
    private lateinit var cbSec: CheckBox
    private lateinit var cbDeep: CheckBox
    private val intervals = longArrayOf(250L, 500L, 1000L, 2000L)
    private var intervalIdx = 1
    private lateinit var btnInterval: Button
    private val ui = Handler(Looper.getMainLooper())
    private var landscape = true
    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    private val cGear = Color.parseColor("#37474F")
    private val cVol = Color.parseColor("#00695C")
    private val cLimit = Color.parseColor("#E65100")
    private val cOpen = Color.parseColor("#1565C0")
    private val cClose = Color.parseColor("#AD1457")
    private val cMisc = Color.parseColor("#455A64")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val dm = resources.displayMetrics
        landscape = dm.widthPixels > dm.heightPixels

        toggle = Button(this).apply { textSize = 18f; setTextColor(Color.WHITE); setOnClickListener { onToggle() } }
        status = TextView(this).apply { textSize = 11f }
        lastMark = TextView(this).apply { textSize = 12f; setTextColor(Color.parseColor("#FFD54F")); text = "Son isaret: -" }
        cbSerial = CheckBox(this).apply { text = "Seri port dinle (ttyS1 bos cikti, kapali)"; textSize = 11f; isChecked = false }
        cbSec = CheckBox(this).apply { text = "Sistem + guvenlik taramasi"; textSize = 11f; isChecked = true }
        etNote = EditText(this).apply { hint = "not (ekrandaki deger vb.)"; textSize = 12f; setSingleLine() }
        val noteBtn = Button(this).apply {
            text = "Ekle"; textSize = 12f; minHeight = 0; minimumHeight = 0
            setOnClickListener {
                val t = etNote.text.toString().trim()
                if (t.isNotEmpty()) { sendMark("NOT: $t", null); etNote.setText("") }
            }
        }
        val noteRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(etNote, LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(noteBtn, LinearLayout.LayoutParams(WRAP, WRAP))
        }

        // ---- Sol kolon: kayit + durum ----
        val left = col()
        left.addView(toggle, vlp(dp(72), 3f))
        if (landscape) left.addView(ScrollView(this).apply { addView(status) }, LinearLayout.LayoutParams(MATCH, 0, 4f))
        else left.addView(status, LinearLayout.LayoutParams(MATCH, WRAP))
        left.addView(lastMark, LinearLayout.LayoutParams(MATCH, WRAP))
        left.addView(cbSerial, LinearLayout.LayoutParams(MATCH, WRAP))
        left.addView(cbSec, LinearLayout.LayoutParams(MATCH, WRAP))
        cbDeep = CheckBox(this).apply { text = "Derin izleme (ozellik/ayar/HCN APK/yayin)"; textSize = 11f; isChecked = true }
        left.addView(cbDeep, LinearLayout.LayoutParams(MATCH, WRAP))
        btnInterval = Button(this).apply {
            textSize = 12f; isAllCaps = false; minHeight = 0; minimumHeight = 0
            text = "Ornekleme: ${intervals[intervalIdx]} ms (dokun: degistir)"
            setOnClickListener {
                intervalIdx = (intervalIdx + 1) % intervals.size
                text = "Ornekleme: ${intervals[intervalIdx]} ms (dokun: degistir)"
            }
        }
        left.addView(btnInterval, LinearLayout.LayoutParams(MATCH, WRAP))
        left.addView(noteRow, LinearLayout.LayoutParams(MATCH, WRAP))

        // ---- Orta kolon: vites, ses, limitleyici, motor, diger ----
        val mid = col()
        mid.addView(title("Vites"))
        mid.addView(hrow(
            mk("1", "VITES:1", cGear), mk("2", "VITES:2", cGear), mk("3", "VITES:3", cGear),
            mk("4", "VITES:4", cGear), mk("5", "VITES:5", cGear), mk("R", "VITES:R", cGear), mk("N", "VITES:N", cGear)
        ), vlp(dp(52)))
        mid.addView(title("Orijinal radyo ses tuslari"))
        mid.addView(hrow(
            mk("Ses +", "SES:+", cVol), mk("Ses -", "SES:-", cVol), mk("Ses butonu (basma)", "SES:BASMA", cVol)
        ), vlp(dp(52)))
        mid.addView(title("Hiz limitleyici ayari  (ayar = GPS hizi)"))
        mid.addView(hrow(
            mk("51 (50)", "LIMIT:ayar51_gps50", cLimit), mk("61 (60)", "LIMIT:ayar61_gps60", cLimit),
            mk("82 (80)", "LIMIT:ayar82_gps80", cLimit), mk("112 (110)", "LIMIT:ayar112_gps110", cLimit),
            mk("Kapali", "LIMIT:KAPALI", cLimit)
        ), vlp(dp(52)))
        mid.addView(title("Motor / surus"))
        mid.addView(hrow(
            mk("Rolanti", "MOTOR:ROLANTI", cMisc), mk("Sabit hiz", "MOTOR:SABIT_HIZ", cMisc),
            mk("Gaza tam", "MOTOR:GAZ_TAM", cMisc), mk("Fren", "MOTOR:FREN", cMisc),
            mk("Yol bilg. sayfa", "MOTOR:YOLBILG_SAYFA", cMisc)
        ), vlp(dp(52)))
        mid.addView(title("Diger"))
        mid.addView(hrow(
            mk("Kapi +", "KAPI:ACILDI", cMisc), mk("Kapi -", "KAPI:KAPANDI", cMisc),
            mk("Sol sinyal", "SINYAL:SOL", cMisc), mk("Sag sinyal", "SINYAL:SAG", cMisc),
            mk("Far", "FAR:DEGISTI", cMisc), mk("Klima", "KLIMA:DEGISTI", cMisc)
        ), vlp(dp(52)))

        // ---- Sag kolon: camlar ----
        val right = col()
        right.addView(title("Camlar  (1. / 2. kademe)"))
        listOf("Sol on" to "SOL_ON", "Sag on" to "SAG_ON", "Sol arka" to "SOL_ARKA", "Sag arka" to "SAG_ARKA").forEach { (name, c) ->
            right.addView(hrow(
                lbl(name),
                mk("Ac 1", "CAM:$c:AC:1", cOpen), mk("Ac 2", "CAM:$c:AC:2", cOpen),
                mk("Kapat 1", "CAM:$c:KAPAT:1", cClose), mk("Kapat 2", "CAM:$c:KAPAT:2", cClose)
            ), vlp(dp(52)))
        }

        if (landscape) {
            val root = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            root.addView(left, LinearLayout.LayoutParams(0, MATCH, 3f))
            root.addView(mid, LinearLayout.LayoutParams(0, MATCH, 4f))
            root.addView(right, LinearLayout.LayoutParams(0, MATCH, 4f))
            setContentView(root)
        } else {
            val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            root.addView(left); root.addView(mid); root.addView(right)
            setContentView(ScrollView(this).apply { addView(root) })
        }

        if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        }
        tryRootGrant()
        tick()
    }

    // ---------- UI yardimcilari ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun col() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(4), dp(2), dp(4), dp(2))
    }

    private fun title(t: String) = TextView(this).apply {
        text = t; textSize = 11f; setTextColor(Color.parseColor("#90A4AE")); setPadding(dp(4), dp(2), 0, 0)
    }

    private fun lbl(t: String) = TextView(this).apply {
        text = t; textSize = 12f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
    }

    private fun mk(text: String, code: String, color: Int) = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 12f
        minHeight = 0; minimumHeight = 0; minWidth = 0; minimumWidth = 0
        setPadding(dp(2), dp(2), dp(2), dp(2))
        setTextColor(Color.WHITE)
        setBackgroundColor(color)
        setOnClickListener { v -> sendMark(code, v) }
    }

    private fun hrow(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEach {
            addView(it, LinearLayout.LayoutParams(0, MATCH, 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
        }
    }

    /** Yatayda satirlar ekrani paylasir (agirlik), dikeyde (telefon) sabit yukseklik. */
    private fun vlp(portraitH: Int, w: Float = 1f) =
        if (landscape) LinearLayout.LayoutParams(MATCH, 0, w) else LinearLayout.LayoutParams(MATCH, portraitH, 0f)

    // ---------- Islevler ----------
    private fun has(p: String): Boolean =
        Build.VERSION.SDK_INT < 23 || checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun tryRootGrant() {
        if (has("android.permission.READ_LOGS") && has("android.permission.DUMP")) return
        Thread {
            try {
                val cmd = "pm grant com.nedim.canlog2 android.permission.READ_LOGS; pm grant com.nedim.canlog2 android.permission.DUMP; appops set com.nedim.canlog2 GET_USAGE_STATS allow"
                val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
                p.waitFor()
            } catch (e: Exception) {}
        }.start()
    }

    private fun onToggle() {
        val i = Intent(this, RecorderService::class.java)
        if (RecorderService.running) {
            i.action = RecorderService.ACT_STOP
            startService(i)
        } else {
            i.action = RecorderService.ACT_START
            i.putExtra(RecorderService.EXTRA_SERIAL, cbSerial.isChecked)
            i.putExtra(RecorderService.EXTRA_SEC, cbSec.isChecked)
            i.putExtra(RecorderService.EXTRA_DEEP, cbDeep.isChecked)
            i.putExtra(RecorderService.EXTRA_INTERVAL, intervals[intervalIdx])
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        }
    }

    private fun sendMark(code: String, v: View?) {
        if (!RecorderService.running) { lastMark.text = "Once kaydi baslat!"; return }
        val i = Intent(this, RecorderService::class.java)
        i.action = RecorderService.ACT_MARK
        i.putExtra(RecorderService.EXTRA_LABEL, code)
        startService(i)
        lastMark.text = "Son isaret: $code  (" + SimpleDateFormat("HH:mm:ss", Locale.US).format(Date()) + ")"
        v?.let { it.alpha = 0.35f; ui.postDelayed({ it.alpha = 1f }, 250) }
    }

    private fun tick() {
        val r = RecorderService.running
        toggle.text = if (r) "■  KAYDI BITIR" else "●  KAYDI BASLAT"
        toggle.setBackgroundColor(if (r) Color.parseColor("#C62828") else Color.parseColor("#2E7D32"))
        val sb = StringBuilder()
        val logOk = has("android.permission.READ_LOGS")
        val dumpOk = has("android.permission.DUMP")
        sb.append("READ_LOGS: ${if (logOk) "VAR" else "YOK"}  DUMP: ${if (dumpOk) "VAR" else "YOK"}  Konum: ${if (has(Manifest.permission.ACCESS_FINE_LOCATION)) "VAR" else "YOK"}\n")
        if (!logOk || !dumpOk) sb.append("! adb: pm grant com.nedim.canlog2 android.permission.READ_LOGS / DUMP\n")
        if (r) {
            val sec = (System.currentTimeMillis() - RecorderService.startMs) / 1000
            sb.append("Sure %d:%02d:%02d  Satir %d  %.1f MB\n".format(sec / 3600, sec % 3600 / 60, sec % 60, RecorderService.rows, RecorderService.bytes / 1048576.0))
            sb.append("Logcat etiket ${RecorderService.tagCount}  Bcast ${RecorderService.bcastCount}  GPS ${RecorderService.gpsCount}\n")
            sb.append("Ozellik degisimi ${RecorderService.propChanges}  Ayar degisimi ${RecorderService.settChanges}  APK satiri ${RecorderService.apkStrings}\n")
            if (RecorderService.serialPorts > 0) sb.append("Seri: ${RecorderService.serialPorts} port, ${RecorderService.serialBytes} bayt\n")
            if (sec > 10 && RecorderService.tagCount <= 1) sb.append("! Logcat bos (READ_LOGS yok olabilir)\n")
            if (sec > 20 && RecorderService.gpsCount == 0) sb.append("! GPS verisi yok\n")
        }
        if (RecorderService.note.isNotEmpty()) sb.append("Not: ${RecorderService.note}\n")
        if (RecorderService.path.isNotEmpty()) {
            sb.append("Dosya: ${RecorderService.path}\n")
            if (RecorderService.downloadCopy.isNotEmpty()) sb.append("Kopya: ${RecorderService.downloadCopy}\n")
        }
        status.text = sb.toString()
        ui.postDelayed({ tick() }, 1000)
    }
}
